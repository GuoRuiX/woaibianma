package com.zbf.woaibianma.core.mybatis;

public class PageInterceptor {

}
