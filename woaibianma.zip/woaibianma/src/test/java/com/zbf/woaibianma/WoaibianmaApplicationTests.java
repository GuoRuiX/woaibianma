package com.zbf.woaibianma;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class WoaibianmaApplicationTests {

    @Test
    public void contextLoads() {
    }

}
